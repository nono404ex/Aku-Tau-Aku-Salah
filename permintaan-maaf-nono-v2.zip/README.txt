web permintaan maaf

1. buka index.html untuk melihat web.
2. ganti file music.mp3 dengan lagu kamu sendiri.
3. jangan ubah nama file lagu, tetap music.mp3.
4. untuk GitHub Pages, upload seluruh isi folder ini ke repository.
